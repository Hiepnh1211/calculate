## General info
This project is a simple calculator.

## User Interface 
![Calculator UI](https://user-images.githubusercontent.com/48919716/114433184-cde0fe80-9bc1-11eb-9e5f-c6b38bb30337.png)

